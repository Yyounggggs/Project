

from sense_hat import SenseHat
import MySQLdb
import time

import RPi.GPIO as GPIO
import time

past_temp=0
temp_sum=0
past_humi=0
humi_sum=0
count=0
detection=0
module_number=2 #raspberry module에 따라 number 변경
angle=0

def buzzer():
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(12, GPIO.OUT)

    try:
        while True:
            GPIO.output(12, True)
            time.sleep(0.05)
            GPIO.output(12, False)
            time.sleep(0.05)

    finally:
        GPIO.cleanup()

def led():
    sense = SenseHat()
    red = (255, 0, 0)
    sense.clear(red)



def InsertData(moduleNumber,temp,humi,angle,detection):
    conn= MySQLdb.connect(host='220.69.247.10',user='root',password='selab417', db= 'fire',charset='utf8')
    cursor= conn.cursor()

    sql="INSERT INTO info(module_number,Temperature,Humidity, Angle, Detection) VALUES(%s,%s,%s, %s, %s)"
    cursor.execute(sql,(moduleNumber,temp,humi,angle,detection))

    conn.commit()
    conn.close()

while True:
    sense= SenseHat()
    temp= sense.get_temperature()
    humidity= sense.get_humidity()
    humi_sum= humidity+humi_sum
    temp_sum= temp+temp_sum
    angle= sense.get_compass()
    count+=1
    print("temperature: "+str(temp)+" count: "+str(count))

    if count==9:
        if ((past_temp!= 0 and past_humi!= 0) and ((temp_sum/10)-past_temp>10 or (humi_sum/10)-past_humi<-10)):
            detection=1
            InsertData(module_number,past_temp,past_humi,angle,detection)
            led()
            buzzer()
            print("total temperature: "+str(temp_sum))
            print("mean temperature: "+ str(temp_sum/10))

        print("mean humidity: " + str(humi_sum/10))
        print(temp_sum)
        print(past_temp)

        print(humi_sum)
        print(past_humi)

        past_temp=(temp_sum/10)
        past_humi=(humi_sum/10)
        InsertData(module_number,past_temp,past_humi,angle,detection)
        temp_sum=0
        humi_sum=0
        count=0
    time.sleep(30);
